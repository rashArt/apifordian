## Usar docker
Se puede personalizar el archivo `docker-compose.yml` para modificar puertos y rutas locales, por ejemplo el servicio `api_app` expone el puerto 8081 para el api y el servicio `db_app` el 3307 para acceso a la base de datos.

## Pasos para levantar el api usando docker
* `docker-compose up -d`

Esperar unos 10 segundos mientras se levanta la base de datos y luego ejecutar:

* `docker exec -it api_app sh -c "unzip -o storage.zip && php artisan migrate:refresh --seed && php artisan config:cache && php artisan config:clear && php artisan cache:clear"`

## Actualizaciones
Hay que saber manejar algo de docker ya que para ejecutar actualizaciones del repo se debe hacer desde el contenedor por ejemplo:

* `docker exec -it api_app /bin/bash`

Y dentro del contenedor si ejecutar git pull
#!/usr/bin/env bash

echo "Inicio crear usuarios"

mysql --user=root --password="$MYSQL_ROOT_PASSWORD" <<-EOSQL
    CREATE DATABASE IF NOT EXISTS $MYSQL_DATABASE DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
    CREATE USER IF NOT EXISTS $MYSQL_USER IDENTIFIED BY $MYSQL_PASSWORD;
EOSQL

echo "Privilegios usuarios"

mysql --user=root --password="$MYSQL_ROOT_PASSWORD" <<-EOSQL
    GRANT ALL PRIVILEGES ON \`$MYSQL_DATABASE%\`.* TO '$MYSQL_USER'@'%';
EOSQL

echo "Crea usuarios"